const consentOutput = document.getElementById('consentOutput');
const auditLog = document.getElementById('auditLog');
const pinStatus = document.getElementById('pinStatus');

function nowStamp() {
  return new Date().toLocaleString();
}

function addAudit(message) {
  const item = document.createElement('li');
  item.textContent = `[${nowStamp()}] ${message}`;
  auditLog.prepend(item);
}

function getSelectedDataTypes() {
  return Array.from(document.querySelectorAll('#consentForm fieldset:first-of-type input:checked'))
    .map((item) => item.value);
}

function buildConsentRecord(status) {
  return {
    participant: document.getElementById('participantName').value || 'Anonymous participant',
    device: document.getElementById('deviceModel').value,
    purpose: document.getElementById('purpose').value,
    duration: document.getElementById('duration').value,
    dataTypes: getSelectedDataTypes(),
    protections: {
      pseudonymized: document.getElementById('anonToggle').checked,
      encryptedBeforeSync: document.getElementById('encryptToggle').checked,
      auditLoggingEnabled: document.getElementById('auditToggle').checked,
    },
    consentStatus: status,
    timestamp: nowStamp(),
  };
}

document.getElementById('saveConsentBtn').addEventListener('click', () => {
  const record = buildConsentRecord('Active');
  localStorage.setItem('garminConsentRecord', JSON.stringify(record, null, 2));
  consentOutput.textContent = JSON.stringify(record, null, 2);
  addAudit(`Consent saved for ${record.participant}.`);
});

document.getElementById('revokeConsentBtn').addEventListener('click', () => {
  const record = buildConsentRecord('Revoked');
  localStorage.setItem('garminConsentRecord', JSON.stringify(record, null, 2));
  consentOutput.textContent = JSON.stringify(record, null, 2);
  addAudit(`Consent revoked for ${record.participant}.`);
});

document.getElementById('createPinBtn').addEventListener('click', () => {
  const pin = document.getElementById('newPin').value.trim();
  const confirmPin = document.getElementById('confirmPin').value.trim();

  if (!/^\d{4}$/.test(pin)) {
    pinStatus.textContent = 'PIN must be exactly 4 digits.';
    addAudit('Failed PIN creation attempt: invalid format.');
    return;
  }

  if (pin !== confirmPin) {
    pinStatus.textContent = 'PIN confirmation does not match.';
    addAudit('Failed PIN creation attempt: mismatch.');
    return;
  }

  localStorage.setItem('demoPin', pin);
  pinStatus.textContent = 'PIN created successfully.';
  addAudit('Local PIN created for dashboard access.');
});

document.getElementById('unlockBtn').addEventListener('click', () => {
  const savedPin = localStorage.getItem('demoPin');
  const enteredPin = document.getElementById('unlockPin').value.trim();

  if (!savedPin) {
    pinStatus.textContent = 'Create a PIN first.';
    addAudit('Unlock attempt blocked because no PIN exists.');
    return;
  }

  if (enteredPin === savedPin) {
    pinStatus.textContent = 'Access granted. Privacy dashboard unlocked.';
    addAudit('Successful dashboard unlock with PIN/passcode.');
  } else {
    pinStatus.textContent = 'Incorrect PIN. Access denied.';
    addAudit('Failed dashboard unlock attempt.');
  }
});

window.addEventListener('DOMContentLoaded', () => {
  const savedConsent = localStorage.getItem('garminConsentRecord');
  if (savedConsent) {
    consentOutput.textContent = savedConsent;
  }
  addAudit('Prototype loaded. Ready for consent and PIN demo.');
});

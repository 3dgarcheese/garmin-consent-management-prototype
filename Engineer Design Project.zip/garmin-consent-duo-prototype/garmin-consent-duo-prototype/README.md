# Garmin Venu Consent + Duo-Style PIN Prototype

This small-scale class project demonstrates two parts of a wearable-device privacy framework:

1. **User consent model** for Garmin Venu-series smartwatch data
2. **Duo-style PIN/passcode access screen** for a companion privacy dashboard

## Important note
This project is an **educational prototype only**. It is **not** the official Garmin Connect app or the official Cisco Duo app.

## Project structure

- `src/index.html` - main interface
- `src/styles.css` - styling
- `src/app.js` - app logic
- `.vscode/launch.json` - VS Code browser launch config
- `.vscode/extensions.json` - suggested extensions
- `consent_model_explanation.md` - write-up for report/presentation

## How to run in Visual Studio Code

### Option 1: Live Server
1. Open this folder in **Visual Studio Code**
2. Install the **Live Server** extension if prompted
3. Right-click `src/index.html`
4. Click **Open with Live Server**

### Option 2: Open directly
1. Open the folder in VS Code
2. Open `src/index.html` in your browser

## Demo checklist

- Enter participant information
- Select what smartwatch data can be shared
- Save consent
- Revoke consent to demonstrate user control
- Create a 4-digit PIN
- Unlock the dashboard with the correct PIN
- Review the audit log

## talking points

- Consent should be **granular** (users choose exactly which data is shared)
- Consent should be **revocable** at any time
- Access should be protected with **local authentication**
- Health and activity data should be **encrypted** and **logged for auditing**
- Privacy settings should be designed for **clarity**, not hidden in long policies

# Consent Model Explanation for the Class Project

## Project goal
The goal is to build a small-scale prototype showing how a privacy-preserving framework could work for Garmin Venu-series smartwatches and their companion apps.

## Why consent matters
Garmin Venu-series watches can collect sensitive information such as:

- heart rate
- sleep data
- blood oxygen
- GPS routes
- workout history
- stress metrics

Because these data types can reveal health status, routines, and location patterns, the user should be able to control who gets access and for how long.

## Proposed consent model
The prototype uses a **user-centric consent model** with these features:

### 1. Granular permissions
Instead of a single “accept all” button, the user can choose specific categories of data to share.

### 2. Purpose limitation
The user can see why the data is being requested, such as health insights, fitness coaching, or research.

### 3. Time-limited consent
The user can approve access for 7 days, 30 days, 90 days, or until revoked.

### 4. Revocation
The user can revoke consent, which changes the record status and demonstrates ongoing control.

### 5. Privacy protections
The interface includes options for:
- pseudonymization
- encryption before cloud sync
- audit logging

## PIN/passcode security layer
The project also adds a **Duo-style local PIN/passcode screen** to protect access to the app dashboard.
This demonstrates a second protection layer for sensitive smartwatch information.

## How this connects to your proposal
This prototype supports the proposal by showing:

- user-controlled data sharing
- transparency in permissions
- stronger app access protection
- a small audit trail for accountability

## Limitations
This is a front-end demo and does not include:

- real Garmin APIs
- real Bluetooth Low Energy communication
- real cryptographic key management
- real Cisco Duo integration
- real blockchain consent ledger

## Future improvements
For a larger version of the project, you could add:

- backend storage for consent records
- encryption of records at rest
- role-based access for third parties
- wearable data simulation
- stronger MFA such as OTP or push approval

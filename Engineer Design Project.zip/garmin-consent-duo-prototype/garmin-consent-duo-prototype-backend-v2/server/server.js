const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const dataPath = path.join(__dirname, 'data.json');
const srcDir = path.join(__dirname, '..', 'src');

const MAX_FAILED_ATTEMPTS = 3;
const LOCKOUT_MINUTES = 5;
const PIN_TTL_MINUTES = 5;

app.use(cors());
app.use(express.json());
app.use(express.static(srcDir));

function readDb() {
  try {
    return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
  } catch (error) {
    return { consents: [], pin: null, auditLog: [] };
  }
}

function writeDb(db) {
  fs.writeFileSync(dataPath, JSON.stringify(db, null, 2));
}

function now() {
  return new Date();
}

function nowStamp() {
  return now().toISOString();
}

function addAudit(db, message, level = 'info') {
  db.auditLog.unshift({
    timestamp: nowStamp(),
    level,
    message,
  });
}

function hashPin(pin, salt) {
  return crypto.createHash('sha256').update(`${pin}:${salt}`).digest('hex');
}

function durationToExpiration(duration, createdAtIso) {
  if (duration === 'Until revoked') {
    return null;
  }

  const created = new Date(createdAtIso);
  const mapping = {
    '7 days': 7,
    '30 days': 30,
    '90 days': 90,
  };

  const days = mapping[duration];
  if (!days) {
    return null;
  }

  created.setDate(created.getDate() + days);
  return created.toISOString();
}

function consentStatus(consent) {
  if (!consent) {
    return 'None';
  }
  if (consent.consentStatus === 'Revoked') {
    return 'Revoked';
  }
  if (consent.expiresAt && new Date(consent.expiresAt) <= now()) {
    return 'Expired';
  }
  return 'Active';
}

function decorateConsent(consent) {
  if (!consent) {
    return null;
  }

  return {
    ...consent,
    effectiveStatus: consentStatus(consent),
  };
}

function pinIsExpired(pinRecord) {
  return Boolean(pinRecord?.expiresAt) && new Date(pinRecord.expiresAt) <= now();
}

function pinIsLocked(pinRecord) {
  return Boolean(pinRecord?.lockedUntil) && new Date(pinRecord.lockedUntil) > now();
}

function minutesRemaining(isoTime) {
  if (!isoTime) {
    return null;
  }
  const ms = new Date(isoTime).getTime() - Date.now();
  return Math.max(0, Math.ceil(ms / 60000));
}

function validateConsentPayload(body) {
  if (!body.participant || typeof body.participant !== 'string') {
    return 'Participant name is required.';
  }
  if (!body.device || typeof body.device !== 'string') {
    return 'Device model is required.';
  }
  if (!body.purpose || typeof body.purpose !== 'string') {
    return 'Purpose is required.';
  }
  if (!body.duration || typeof body.duration !== 'string') {
    return 'Consent duration is required.';
  }
  if (!Array.isArray(body.dataTypes) || body.dataTypes.length === 0) {
    return 'Select at least one data type.';
  }
  return null;
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, message: 'Backend simulation is running.' });
});

app.get('/api/consent/latest', (_req, res) => {
  const db = readDb();
  const latest = decorateConsent(db.consents[0] || null);
  res.json({ consent: latest });
});

app.post('/api/consent/save', (req, res) => {
  const error = validateConsentPayload(req.body);
  if (error) {
    return res.status(400).json({ error });
  }

  const db = readDb();
  const timestamp = nowStamp();
  const record = {
    id: crypto.randomUUID(),
    participant: req.body.participant.trim(),
    device: req.body.device,
    purpose: req.body.purpose,
    duration: req.body.duration,
    dataTypes: req.body.dataTypes,
    protections: {
      pseudonymized: Boolean(req.body.protections?.pseudonymized),
      encryptedBeforeSync: Boolean(req.body.protections?.encryptedBeforeSync),
      auditLoggingEnabled: Boolean(req.body.protections?.auditLoggingEnabled),
    },
    consentStatus: 'Active',
    timestamp,
    expiresAt: durationToExpiration(req.body.duration, timestamp),
  };

  db.consents.unshift(record);
  const expiryText = record.expiresAt
    ? ` It will expire on ${new Date(record.expiresAt).toLocaleString()}.`
    : ' It remains active until revoked.';
  addAudit(db, `Consent saved for ${record.participant}.${expiryText}`);
  writeDb(db);
  return res.status(201).json({ message: 'Consent saved.', consent: decorateConsent(record) });
});

app.post('/api/consent/revoke', (req, res) => {
  const error = validateConsentPayload(req.body);
  if (error) {
    return res.status(400).json({ error });
  }

  const db = readDb();
  const record = {
    id: crypto.randomUUID(),
    participant: req.body.participant.trim(),
    device: req.body.device,
    purpose: req.body.purpose,
    duration: req.body.duration,
    dataTypes: req.body.dataTypes,
    protections: {
      pseudonymized: Boolean(req.body.protections?.pseudonymized),
      encryptedBeforeSync: Boolean(req.body.protections?.encryptedBeforeSync),
      auditLoggingEnabled: Boolean(req.body.protections?.auditLoggingEnabled),
    },
    consentStatus: 'Revoked',
    timestamp: nowStamp(),
    revokedAt: nowStamp(),
    expiresAt: null,
  };

  db.consents.unshift(record);
  addAudit(db, `Consent revoked for ${record.participant}.`, 'warning');
  writeDb(db);
  return res.json({ message: 'Consent revoked.', consent: decorateConsent(record) });
});

app.get('/api/audit-log', (_req, res) => {
  const db = readDb();
  res.json({ auditLog: db.auditLog });
});

app.get('/api/pin/status', (_req, res) => {
  const db = readDb();

  if (!db.pin) {
    return res.json({
      hasPin: false,
      pinExpired: false,
      pinLocked: false,
      failedAttempts: 0,
      remainingAttempts: MAX_FAILED_ATTEMPTS,
      pinExpiresAt: null,
      lockoutEndsAt: null,
      minutesUntilPinExpires: null,
      minutesUntilUnlock: null,
    });
  }

  return res.json({
    hasPin: true,
    pinExpired: pinIsExpired(db.pin),
    pinLocked: pinIsLocked(db.pin),
    failedAttempts: db.pin.failedAttempts || 0,
    remainingAttempts: Math.max(0, MAX_FAILED_ATTEMPTS - (db.pin.failedAttempts || 0)),
    pinExpiresAt: db.pin.expiresAt,
    lockoutEndsAt: db.pin.lockedUntil || null,
    minutesUntilPinExpires: minutesRemaining(db.pin.expiresAt),
    minutesUntilUnlock: minutesRemaining(db.pin.lockedUntil),
  });
});

app.post('/api/pin/create', (req, res) => {
  const pin = String(req.body.pin || '').trim();
  const confirmPin = String(req.body.confirmPin || '').trim();

  if (!/^\d{4}$/.test(pin)) {
    return res.status(400).json({ error: 'PIN must be exactly 4 digits.' });
  }
  if (pin !== confirmPin) {
    return res.status(400).json({ error: 'PIN confirmation does not match.' });
  }

  const db = readDb();
  const salt = crypto.randomBytes(16).toString('hex');
  const createdAt = nowStamp();
  const expiresAt = new Date(Date.now() + PIN_TTL_MINUTES * 60000).toISOString();

  db.pin = {
    salt,
    hash: hashPin(pin, salt),
    createdAt,
    expiresAt,
    failedAttempts: 0,
    lockedUntil: null,
  };
  addAudit(db, `Local PIN created for dashboard access. The PIN expires in ${PIN_TTL_MINUTES} minutes.`);
  writeDb(db);
  return res.status(201).json({
    message: `PIN created successfully. It expires in ${PIN_TTL_MINUTES} minutes.`,
    pinExpiresAt: expiresAt,
  });
});

app.post('/api/pin/unlock', (req, res) => {
  const enteredPin = String(req.body.pin || '').trim();
  const db = readDb();

  if (!db.pin) {
    addAudit(db, 'Unlock attempt blocked because no PIN exists.', 'warning');
    writeDb(db);
    return res.status(400).json({ error: 'Create a PIN first.' });
  }

  if (pinIsExpired(db.pin)) {
    addAudit(db, 'Unlock attempt blocked because the PIN expired.', 'warning');
    writeDb(db);
    return res.status(401).json({ error: 'PIN expired. Create a new PIN.' });
  }

  if (pinIsLocked(db.pin)) {
    const remaining = minutesRemaining(db.pin.lockedUntil);
    addAudit(db, `Unlock attempt blocked during lockout window (${remaining} minutes remaining).`, 'warning');
    writeDb(db);
    return res.status(423).json({ error: `Too many failed attempts. Try again in ${remaining} minute(s).` });
  }

  const attemptedHash = hashPin(enteredPin, db.pin.salt);
  if (attemptedHash === db.pin.hash) {
    db.pin.failedAttempts = 0;
    db.pin.lockedUntil = null;
    addAudit(db, 'Successful dashboard unlock with PIN/passcode.');
    writeDb(db);
    return res.json({ message: 'Access granted. Privacy dashboard unlocked.' });
  }

  db.pin.failedAttempts = (db.pin.failedAttempts || 0) + 1;
  const attemptsLeft = Math.max(0, MAX_FAILED_ATTEMPTS - db.pin.failedAttempts);

  if (db.pin.failedAttempts >= MAX_FAILED_ATTEMPTS) {
    db.pin.lockedUntil = new Date(Date.now() + LOCKOUT_MINUTES * 60000).toISOString();
    addAudit(db, `Dashboard lockout started after ${db.pin.failedAttempts} failed attempts. Locked for ${LOCKOUT_MINUTES} minutes.`, 'warning');
    writeDb(db);
    return res.status(423).json({
      error: `Too many failed attempts. Dashboard locked for ${LOCKOUT_MINUTES} minutes.`,
    });
  }

  addAudit(db, `Failed dashboard unlock attempt (${db.pin.failedAttempts} failed attempts, ${attemptsLeft} attempt(s) remaining).`, 'warning');
  writeDb(db);
  return res.status(401).json({
    error: `Incorrect PIN. ${attemptsLeft} attempt(s) remaining before lockout.`,
  });
});

app.post('/api/reset', (_req, res) => {
  const db = { consents: [], pin: null, auditLog: [] };
  addAudit(db, 'Prototype state reset by user.');
  writeDb(db);
  res.json({ message: 'Prototype state reset.' });
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(srcDir, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Backend simulation running at http://localhost:${PORT}`);
});

# Garmin Venu Consent + Duo-Style PIN Prototype

This small-scale class project demonstrates two parts of a wearable-device privacy framework:

1. **User consent model** for Garmin Venu-series smartwatch data
2. **Duo-style PIN/passcode access screen** for a companion privacy dashboard
3. **Backend simulation** using Node.js and Express for validation, storage, and audit logs

## Important note
This project is an **educational prototype only**. It is **not** the official Garmin Connect app or the official Cisco Duo app.

## Project structure

- `src/index.html` - main interface
- `src/styles.css` - styling
- `src/app.js` - front-end logic that calls the backend simulation
- `server/server.js` - Express backend simulation
- `server/data.json` - local JSON storage for consent, PIN metadata, and audit logs
- `.vscode/launch.json` - VS Code browser launch config
- `.vscode/extensions.json` - suggested extensions
- `consent_model_explanation.md` - write-up for report/presentation

## How to run in Visual Studio Code

### Recommended: run the backend simulation
1. Open this folder in **Visual Studio Code**
2. Open a terminal in VS Code
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

### Optional: use Live Server for the front end
You can still use Live Server for `src/index.html`, but the Node server must also be running because the front end calls `http://localhost:3000/api`.

## Simulated backend features

- Save and revoke consent records
- Validate that at least one data type is selected
- Store consent history with timestamps
- Hash the 4-digit PIN before storage
- Verify unlock attempts on the server side
- Record audit log events for consent and authentication

## Demo checklist

- Enter participant information
- Select what smartwatch data can be shared
- Save consent
- Revoke consent to demonstrate user control
- Create a 4-digit PIN
- Unlock the dashboard with the correct PIN
- Review the audit log

## Why the backend simulation matters

The original version stored everything in browser local storage. This version moves validation and storage to a lightweight backend so the demo better represents how a real system would:

- enforce consent rules on the server side
- protect authentication logic from direct front-end editing
- keep an audit trail outside the browser UI
- separate client actions from policy enforcement

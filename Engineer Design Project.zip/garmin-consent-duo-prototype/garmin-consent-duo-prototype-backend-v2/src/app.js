const consentOutput = document.getElementById('consentOutput');
const auditLog = document.getElementById('auditLog');
const pinStatus = document.getElementById('pinStatus');
const pinMeta = document.getElementById('pinMeta');

const API_BASE = window.location.port === '3000'
  ? `${window.location.origin}/api`
  : `${window.location.protocol}//${window.location.hostname}:3000/api`;

function formatTimestamp(value) {
  return new Date(value).toLocaleString();
}

function renderAuditLog(items) {
  auditLog.innerHTML = '';
  if (!items.length) {
    const item = document.createElement('li');
    item.textContent = 'No audit events yet.';
    auditLog.appendChild(item);
    return;
  }

  items.forEach((entry) => {
    const item = document.createElement('li');
    item.textContent = `[${formatTimestamp(entry.timestamp)}] ${entry.message}`;
    auditLog.appendChild(item);
  });
}

function getSelectedDataTypes() {
  return Array.from(document.querySelectorAll('#consentForm fieldset:first-of-type input:checked'))
    .map((item) => item.value);
}

function buildConsentPayload() {
  return {
    participant: document.getElementById('participantName').value.trim() || 'Anonymous participant',
    device: document.getElementById('deviceModel').value,
    purpose: document.getElementById('purpose').value,
    duration: document.getElementById('duration').value,
    dataTypes: getSelectedDataTypes(),
    protections: {
      pseudonymized: document.getElementById('anonToggle').checked,
      encryptedBeforeSync: document.getElementById('encryptToggle').checked,
      auditLoggingEnabled: document.getElementById('auditToggle').checked,
    },
  };
}

async function apiFetch(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || 'Request failed.');
  }
  return data;
}

async function refreshConsent() {
  try {
    const data = await apiFetch('/consent/latest');
    consentOutput.textContent = data.consent
      ? JSON.stringify(data.consent, null, 2)
      : 'No consent record created yet.';
  } catch (error) {
    consentOutput.textContent = `Backend unavailable: ${error.message}`;
  }
}

async function refreshAuditLog() {
  try {
    const data = await apiFetch('/audit-log');
    renderAuditLog(data.auditLog || []);
  } catch (error) {
    renderAuditLog([{ timestamp: new Date().toISOString(), message: `Backend unavailable: ${error.message}` }]);
  }
}

async function refreshPinStatus() {
  try {
    const data = await apiFetch('/pin/status');

    if (!data.hasPin) {
      pinMeta.textContent = 'No PIN active. Create a new 4-digit PIN.';
      return;
    }

    if (data.pinLocked) {
      pinMeta.textContent = `Dashboard temporarily locked. Try again in ${data.minutesUntilUnlock} minute(s).`;
      return;
    }

    if (data.pinExpired) {
      pinMeta.textContent = 'Current PIN expired. Create a new PIN to unlock the dashboard.';
      return;
    }

    pinMeta.textContent = `PIN expires at ${formatTimestamp(data.pinExpiresAt)}. Remaining attempts before lockout: ${data.remainingAttempts}.`;
  } catch (error) {
    pinMeta.textContent = `Backend unavailable: ${error.message}`;
  }
}

document.getElementById('saveConsentBtn').addEventListener('click', async () => {
  try {
    const payload = buildConsentPayload();
    const data = await apiFetch('/consent/save', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    consentOutput.textContent = JSON.stringify(data.consent, null, 2);
  } catch (error) {
    consentOutput.textContent = error.message;
  } finally {
    await refreshAuditLog();
  }
});

document.getElementById('revokeConsentBtn').addEventListener('click', async () => {
  try {
    const payload = buildConsentPayload();
    const data = await apiFetch('/consent/revoke', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    consentOutput.textContent = JSON.stringify(data.consent, null, 2);
  } catch (error) {
    consentOutput.textContent = error.message;
  } finally {
    await refreshAuditLog();
  }
});

document.getElementById('createPinBtn').addEventListener('click', async () => {
  const pin = document.getElementById('newPin').value.trim();
  const confirmPin = document.getElementById('confirmPin').value.trim();

  try {
    const data = await apiFetch('/pin/create', {
      method: 'POST',
      body: JSON.stringify({ pin, confirmPin }),
    });
    pinStatus.textContent = data.message;
    document.getElementById('newPin').value = '';
    document.getElementById('confirmPin').value = '';
  } catch (error) {
    pinStatus.textContent = error.message;
  } finally {
    await refreshPinStatus();
    await refreshAuditLog();
  }
});

document.getElementById('unlockBtn').addEventListener('click', async () => {
  const pin = document.getElementById('unlockPin').value.trim();

  try {
    const data = await apiFetch('/pin/unlock', {
      method: 'POST',
      body: JSON.stringify({ pin }),
    });
    pinStatus.textContent = data.message;
    document.getElementById('unlockPin').value = '';
  } catch (error) {
    pinStatus.textContent = error.message;
  } finally {
    await refreshPinStatus();
    await refreshAuditLog();
  }
});

window.addEventListener('DOMContentLoaded', async () => {
  pinStatus.textContent = 'Backend simulation ready.';
  await refreshConsent();
  await refreshPinStatus();
  await refreshAuditLog();
  window.setInterval(refreshPinStatus, 30000);
});

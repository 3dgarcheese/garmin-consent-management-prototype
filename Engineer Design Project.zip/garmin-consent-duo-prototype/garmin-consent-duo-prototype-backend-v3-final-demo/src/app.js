const consentOutput = document.getElementById('consentOutput');
const auditLog = document.getElementById('auditLog');
const pinStatus = document.getElementById('pinStatus');
const pinMeta = document.getElementById('pinMeta');
const durationMode = document.getElementById('durationMode');
const durationValue = document.getElementById('durationValue');
const durationUnit = document.getElementById('durationUnit');

const API_BASE = window.location.port === '3000'
  ? `${window.location.origin}/api`
  : `${window.location.protocol}//${window.location.hostname}:3000/api`;

function formatTimestamp(value) {
  if (!value) return 'not set';
  return new Date(value).toLocaleString();
}

function setMessage(element, message, kind = 'info') {
  element.textContent = message;
  element.classList.remove('success', 'error', 'warning');
  if (kind !== 'info') element.classList.add(kind);
}

function renderAuditLog(items) {
  auditLog.innerHTML = '';
  if (!items.length) {
    const item = document.createElement('li');
    item.textContent = 'No audit events yet.';
    auditLog.appendChild(item);
    return;
  }

  items.forEach((entry) => {
    const item = document.createElement('li');
    const status = entry.status || entry.level || 'INFO';
    const type = entry.type || 'SYSTEM';
    item.className = `audit-${String(status).toLowerCase()}`;
    item.textContent = `[${formatTimestamp(entry.timestamp)}] [${type}] [${status}] ${entry.message}`;
    auditLog.appendChild(item);
  });
}

function getSelectedDataTypes() {
  return Array.from(document.querySelectorAll('#consentForm fieldset:first-of-type input:checked'))
    .map((item) => item.value);
}

function updateDurationControls() {
  const isUntilRevoked = durationMode.value === 'Until revoked';
  durationValue.disabled = isUntilRevoked;
  durationUnit.disabled = isUntilRevoked;
}

function buildConsentPayload() {
  const mode = durationMode.value;
  const payload = {
    participant: document.getElementById('participantName').value.trim() || 'Anonymous participant',
    device: document.getElementById('deviceModel').value,
    purpose: document.getElementById('purpose').value,
    durationMode: mode,
    dataTypes: getSelectedDataTypes(),
    protections: {
      pseudonymized: document.getElementById('anonToggle').checked,
      encryptedBeforeSync: document.getElementById('encryptToggle').checked,
      auditLoggingEnabled: document.getElementById('auditToggle').checked,
    },
  };

  if (mode === 'custom') {
    payload.durationValue = Number(durationValue.value);
    payload.durationUnit = durationUnit.value;
    payload.duration = `${payload.durationValue} ${payload.durationUnit}`;
  } else {
    payload.duration = 'Until revoked';
  }

  return payload;
}

async function apiFetch(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || 'Request failed.');
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}

async function refreshConsent() {
  try {
    const data = await apiFetch('/consent/latest');
    consentOutput.textContent = data.consent
      ? JSON.stringify(data.consent, null, 2)
      : 'No consent record created yet.';
  } catch (error) {
    consentOutput.textContent = `Backend unavailable: ${error.message}`;
  }
}

async function refreshAuditLog() {
  try {
    const data = await apiFetch('/audit-log');
    renderAuditLog(data.auditLog || []);
  } catch (error) {
    renderAuditLog([{ timestamp: new Date().toISOString(), type: 'SYSTEM', status: 'FAIL', message: `Backend unavailable: ${error.message}` }]);
  }
}

async function refreshPinStatus() {
  try {
    const data = await apiFetch('/pin/status');

    if (!data.hasPin) {
      setMessage(pinMeta, `No PIN active. Active consent status: ${data.consentStatus}. Create a new 4-digit PIN.`, 'info');
      return;
    }

    if (data.pinLocked) {
      setMessage(pinMeta, `Dashboard temporarily locked. Try again in ${data.minutesUntilUnlock} minute(s). Active consent status: ${data.consentStatus}.`, 'warning');
      return;
    }

    if (data.pinExpired) {
      setMessage(pinMeta, `Current PIN expired. Active consent status: ${data.consentStatus}. Create a new PIN to unlock the dashboard.`, 'warning');
      return;
    }

    setMessage(pinMeta, `PIN expires at ${formatTimestamp(data.pinExpiresAt)}. Remaining attempts before lockout: ${data.remainingAttempts}. Active consent status: ${data.consentStatus}.`, 'info');
  } catch (error) {
    setMessage(pinMeta, `Backend unavailable: ${error.message}`, 'error');
  }
}

document.getElementById('saveConsentBtn').addEventListener('click', async () => {
  try {
    const payload = buildConsentPayload();
    const data = await apiFetch('/consent/save', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    consentOutput.textContent = JSON.stringify(data.consent, null, 2);
  } catch (error) {
    consentOutput.textContent = error.message;
  } finally {
    await refreshPinStatus();
    await refreshAuditLog();
  }
});

document.getElementById('revokeConsentBtn').addEventListener('click', async () => {
  try {
    const payload = buildConsentPayload();
    const data = await apiFetch('/consent/revoke', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    consentOutput.textContent = JSON.stringify(data.consent, null, 2);
  } catch (error) {
    consentOutput.textContent = error.message;
  } finally {
    await refreshPinStatus();
    await refreshAuditLog();
  }
});

document.getElementById('createPinBtn').addEventListener('click', async () => {
  const pin = document.getElementById('newPin').value.trim();
  const confirmPin = document.getElementById('confirmPin').value.trim();

  try {
    const data = await apiFetch('/pin/create', {
      method: 'POST',
      body: JSON.stringify({ pin, confirmPin }),
    });
    setMessage(pinStatus, data.message, 'success');
    document.getElementById('newPin').value = '';
    document.getElementById('confirmPin').value = '';
  } catch (error) {
    setMessage(pinStatus, error.message, 'error');
  } finally {
    await refreshPinStatus();
    await refreshAuditLog();
  }
});

document.getElementById('unlockBtn').addEventListener('click', async () => {
  const pin = document.getElementById('unlockPin').value.trim();

  try {
    const data = await apiFetch('/pin/unlock', {
      method: 'POST',
      body: JSON.stringify({ pin }),
    });
    setMessage(pinStatus, data.message, 'success');
    document.getElementById('unlockPin').value = '';
  } catch (error) {
    const kind = error.status === 423 ? 'warning' : 'error';
    setMessage(pinStatus, error.message, kind);
  } finally {
    await refreshPinStatus();
    await refreshAuditLog();
  }
});

document.getElementById('resetDemoBtn').addEventListener('click', async () => {
  if (!window.confirm('Reset all demo data, PIN, consent records, and audit logs?')) return;

  try {
    const data = await apiFetch('/reset', { method: 'POST', body: JSON.stringify({}) });
    setMessage(pinStatus, data.message, 'success');
    consentOutput.textContent = 'No consent record created yet.';
  } catch (error) {
    setMessage(pinStatus, error.message, 'error');
  } finally {
    await refreshConsent();
    await refreshPinStatus();
    await refreshAuditLog();
  }
});

durationMode.addEventListener('change', updateDurationControls);

window.addEventListener('DOMContentLoaded', async () => {
  updateDurationControls();
  setMessage(pinStatus, 'Backend simulation ready.', 'success');
  await refreshConsent();
  await refreshPinStatus();
  await refreshAuditLog();
  window.setInterval(refreshPinStatus, 30000);
});

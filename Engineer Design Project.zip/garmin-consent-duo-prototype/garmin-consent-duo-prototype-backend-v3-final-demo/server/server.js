const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const dataPath = path.join(__dirname, 'data.json');
const srcDir = path.join(__dirname, '..', 'src');

const MAX_FAILED_ATTEMPTS = 3;
const LOCKOUT_MINUTES = 5;
const PIN_TTL_MINUTES = 5;
const MAX_CONSENT_DAYS = 365;

app.use(cors());
app.use(express.json());
app.use(express.static(srcDir));

function readDb() {
  try {
    return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
  } catch (error) {
    return { consents: [], pin: null, auditLog: [] };
  }
}

function writeDb(db) {
  fs.writeFileSync(dataPath, JSON.stringify(db, null, 2));
}

function now() {
  return new Date();
}

function nowStamp() {
  return now().toISOString();
}

function addAudit(db, type, status, message, details = {}) {
  db.auditLog.unshift({
    id: crypto.randomUUID(),
    timestamp: nowStamp(),
    type,        // CONSENT, PIN, SYSTEM
    status,      // SUCCESS, FAIL, WARNING, INFO
    message,
    details,
  });
}

function hashPin(pin, salt) {
  return crypto.createHash('sha256').update(`${pin}:${salt}`).digest('hex');
}

function parseConsentDuration(body) {
  const mode = body.durationMode || body.duration || '7 days';

  if (mode === 'Until revoked') {
    return {
      label: 'Until revoked',
      expiresAt: null,
      durationValue: null,
      durationUnit: null,
    };
  }

  const value = Number(body.durationValue);
  const unit = String(body.durationUnit || '').trim();
  const allowedUnits = ['hours', 'days', 'weeks'];

  if (!Number.isInteger(value) || value < 1) {
    throw new Error('Consent duration value must be a whole number greater than 0.');
  }
  if (!allowedUnits.includes(unit)) {
    throw new Error('Consent duration unit must be hours, days, or weeks.');
  }

  const maxByUnit = { hours: MAX_CONSENT_DAYS * 24, days: MAX_CONSENT_DAYS, weeks: 52 };
  if (value > maxByUnit[unit]) {
    throw new Error(`Consent duration is too long. Maximum is ${maxByUnit[unit]} ${unit}.`);
  }

  const expires = now();
  if (unit === 'hours') expires.setHours(expires.getHours() + value);
  if (unit === 'days') expires.setDate(expires.getDate() + value);
  if (unit === 'weeks') expires.setDate(expires.getDate() + value * 7);

  return {
    label: `${value} ${unit}`,
    expiresAt: expires.toISOString(),
    durationValue: value,
    durationUnit: unit,
  };
}

function consentStatus(consent) {
  if (!consent) return 'None';
  if (consent.consentStatus === 'Revoked') return 'Revoked';
  if (consent.expiresAt && new Date(consent.expiresAt) <= now()) return 'Expired';
  return 'Active';
}

function decorateConsent(consent) {
  if (!consent) return null;
  return {
    ...consent,
    effectiveStatus: consentStatus(consent),
  };
}

function latestActiveConsent(db) {
  const latest = db.consents[0] || null;
  if (!latest) return null;
  return consentStatus(latest) === 'Active' ? latest : null;
}

function pinIsExpired(pinRecord) {
  return Boolean(pinRecord?.expiresAt) && new Date(pinRecord.expiresAt) <= now();
}

function pinIsLocked(pinRecord) {
  return Boolean(pinRecord?.lockedUntil) && new Date(pinRecord.lockedUntil) > now();
}

function minutesRemaining(isoTime) {
  if (!isoTime) return null;
  const ms = new Date(isoTime).getTime() - Date.now();
  return Math.max(0, Math.ceil(ms / 60000));
}

function validateConsentPayload(body) {
  if (!body.participant || typeof body.participant !== 'string') {
    return 'Participant name is required.';
  }
  if (!body.device || typeof body.device !== 'string') {
    return 'Device model is required.';
  }
  if (!body.purpose || typeof body.purpose !== 'string') {
    return 'Purpose is required.';
  }
  if (!body.durationMode && !body.duration) {
    return 'Consent duration is required.';
  }
  if (!Array.isArray(body.dataTypes) || body.dataTypes.length === 0) {
    return 'Select at least one data type.';
  }
  return null;
}

function validatePin(pin) {
  if (!/^\d{4}$/.test(pin)) {
    return 'PIN must be exactly 4 digits.';
  }
  if (/^(\d)\1{3}$/.test(pin)) {
    return 'Weak PIN not allowed: avoid repeating digits like 1111.';
  }
  if (['1234', '4321', '0000', '2580'].includes(pin)) {
    return 'Weak PIN not allowed: avoid common keypad patterns.';
  }
  return null;
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, message: 'Backend simulation is running.' });
});

app.get('/api/consent/latest', (_req, res) => {
  const db = readDb();
  const latest = decorateConsent(db.consents[0] || null);
  res.json({ consent: latest });
});

app.post('/api/consent/save', (req, res) => {
  const error = validateConsentPayload(req.body);
  if (error) {
    const db = readDb();
    addAudit(db, 'CONSENT', 'FAIL', `Consent save rejected: ${error}`);
    writeDb(db);
    return res.status(400).json({ error });
  }

  let durationInfo;
  try {
    durationInfo = parseConsentDuration(req.body);
  } catch (err) {
    const db = readDb();
    addAudit(db, 'CONSENT', 'FAIL', `Consent save rejected: ${err.message}`);
    writeDb(db);
    return res.status(400).json({ error: err.message });
  }

  const db = readDb();
  const timestamp = nowStamp();
  const record = {
    id: crypto.randomUUID(),
    participant: req.body.participant.trim(),
    device: req.body.device,
    purpose: req.body.purpose,
    duration: durationInfo.label,
    durationValue: durationInfo.durationValue,
    durationUnit: durationInfo.durationUnit,
    dataTypes: req.body.dataTypes,
    protections: {
      pseudonymized: Boolean(req.body.protections?.pseudonymized),
      encryptedBeforeSync: Boolean(req.body.protections?.encryptedBeforeSync),
      auditLoggingEnabled: Boolean(req.body.protections?.auditLoggingEnabled),
    },
    consentStatus: 'Active',
    timestamp,
    expiresAt: durationInfo.expiresAt,
  };

  db.consents.unshift(record);
  const expiryText = record.expiresAt
    ? `Expires on ${new Date(record.expiresAt).toLocaleString()}.`
    : 'Active until revoked.';
  addAudit(db, 'CONSENT', 'SUCCESS', `Consent saved for ${record.participant}. ${expiryText}`, {
    participant: record.participant,
    duration: record.duration,
    dataTypes: record.dataTypes,
    expiresAt: record.expiresAt,
  });
  writeDb(db);
  return res.status(201).json({ message: 'Consent saved.', consent: decorateConsent(record) });
});

app.post('/api/consent/revoke', (req, res) => {
  const error = validateConsentPayload(req.body);
  if (error) {
    const db = readDb();
    addAudit(db, 'CONSENT', 'FAIL', `Consent revoke rejected: ${error}`);
    writeDb(db);
    return res.status(400).json({ error });
  }

  const db = readDb();
  const record = {
    id: crypto.randomUUID(),
    participant: req.body.participant.trim(),
    device: req.body.device,
    purpose: req.body.purpose,
    duration: req.body.duration || req.body.durationMode || 'Until revoked',
    dataTypes: req.body.dataTypes,
    protections: {
      pseudonymized: Boolean(req.body.protections?.pseudonymized),
      encryptedBeforeSync: Boolean(req.body.protections?.encryptedBeforeSync),
      auditLoggingEnabled: Boolean(req.body.protections?.auditLoggingEnabled),
    },
    consentStatus: 'Revoked',
    timestamp: nowStamp(),
    revokedAt: nowStamp(),
    expiresAt: null,
  };

  db.consents.unshift(record);
  addAudit(db, 'CONSENT', 'WARNING', `Consent revoked for ${record.participant}.`, {
    participant: record.participant,
    revokedAt: record.revokedAt,
  });
  writeDb(db);
  return res.json({ message: 'Consent revoked.', consent: decorateConsent(record) });
});

app.get('/api/audit-log', (_req, res) => {
  const db = readDb();
  res.json({ auditLog: db.auditLog });
});

app.get('/api/pin/status', (_req, res) => {
  const db = readDb();
  const consent = decorateConsent(db.consents[0] || null);

  if (!db.pin) {
    return res.json({
      hasPin: false,
      pinExpired: false,
      pinLocked: false,
      failedAttempts: 0,
      remainingAttempts: MAX_FAILED_ATTEMPTS,
      pinExpiresAt: null,
      lockoutEndsAt: null,
      minutesUntilPinExpires: null,
      minutesUntilUnlock: null,
      consentStatus: consent?.effectiveStatus || 'None',
    });
  }

  return res.json({
    hasPin: true,
    pinExpired: pinIsExpired(db.pin),
    pinLocked: pinIsLocked(db.pin),
    failedAttempts: db.pin.failedAttempts || 0,
    remainingAttempts: Math.max(0, MAX_FAILED_ATTEMPTS - (db.pin.failedAttempts || 0)),
    pinExpiresAt: db.pin.expiresAt,
    lockoutEndsAt: db.pin.lockedUntil || null,
    minutesUntilPinExpires: minutesRemaining(db.pin.expiresAt),
    minutesUntilUnlock: minutesRemaining(db.pin.lockedUntil),
    consentStatus: consent?.effectiveStatus || 'None',
  });
});

app.post('/api/pin/create', (req, res) => {
  const pin = String(req.body.pin || '').trim();
  const confirmPin = String(req.body.confirmPin || '').trim();
  const pinError = validatePin(pin);

  const db = readDb();
  if (pinError) {
    addAudit(db, 'PIN', 'FAIL', `PIN creation rejected: ${pinError}`);
    writeDb(db);
    return res.status(400).json({ error: pinError });
  }
  if (pin !== confirmPin) {
    addAudit(db, 'PIN', 'FAIL', 'PIN creation rejected: confirmation did not match.');
    writeDb(db);
    return res.status(400).json({ error: 'PIN confirmation does not match.' });
  }

  const salt = crypto.randomBytes(16).toString('hex');
  const createdAt = nowStamp();
  const expiresAt = new Date(Date.now() + PIN_TTL_MINUTES * 60000).toISOString();

  db.pin = {
    salt,
    hash: hashPin(pin, salt),
    createdAt,
    expiresAt,
    failedAttempts: 0,
    lockedUntil: null,
  };
  addAudit(db, 'PIN', 'SUCCESS', `Local PIN created. It expires in ${PIN_TTL_MINUTES} minutes.`, {
    pinExpiresAt: expiresAt,
    maxFailedAttempts: MAX_FAILED_ATTEMPTS,
  });
  writeDb(db);
  return res.status(201).json({
    message: `PIN created successfully. It expires in ${PIN_TTL_MINUTES} minutes.`,
    pinExpiresAt: expiresAt,
    remainingAttempts: MAX_FAILED_ATTEMPTS,
  });
});

app.post('/api/pin/unlock', (req, res) => {
  const enteredPin = String(req.body.pin || '').trim();
  const db = readDb();
  const latestConsent = db.consents[0] || null;
  const effectiveConsentStatus = consentStatus(latestConsent);

  if (!db.pin) {
    addAudit(db, 'PIN', 'FAIL', 'Unlock attempt blocked because no PIN exists.');
    writeDb(db);
    return res.status(400).json({ error: 'Create a PIN first.' });
  }

  if (!latestActiveConsent(db)) {
    addAudit(db, 'PIN', 'FAIL', `Unlock blocked because consent status is ${effectiveConsentStatus}.`);
    writeDb(db);
    return res.status(403).json({ error: `No active consent. Current consent status: ${effectiveConsentStatus}.` });
  }

  if (pinIsExpired(db.pin)) {
    addAudit(db, 'PIN', 'FAIL', 'Unlock attempt blocked because the PIN expired.');
    writeDb(db);
    return res.status(401).json({ error: 'PIN expired. Create a new PIN.' });
  }

  if (pinIsLocked(db.pin)) {
    const remaining = minutesRemaining(db.pin.lockedUntil);
    addAudit(db, 'PIN', 'FAIL', `Unlock blocked during lockout window (${remaining} minute(s) remaining).`, {
      lockedUntil: db.pin.lockedUntil,
    });
    writeDb(db);
    return res.status(423).json({ error: `Too many failed attempts. Try again in ${remaining} minute(s).` });
  }

  const attemptedHash = hashPin(enteredPin, db.pin.salt);
  if (attemptedHash === db.pin.hash) {
    db.pin.failedAttempts = 0;
    db.pin.lockedUntil = null;
    addAudit(db, 'PIN', 'SUCCESS', 'Successful dashboard unlock with PIN/passcode.');
    writeDb(db);
    return res.json({ message: 'Access granted. Privacy dashboard unlocked.' });
  }

  db.pin.failedAttempts = (db.pin.failedAttempts || 0) + 1;
  const attemptsLeft = Math.max(0, MAX_FAILED_ATTEMPTS - db.pin.failedAttempts);

  if (db.pin.failedAttempts >= MAX_FAILED_ATTEMPTS) {
    db.pin.lockedUntil = new Date(Date.now() + LOCKOUT_MINUTES * 60000).toISOString();
    addAudit(db, 'PIN', 'FAIL', `Dashboard lockout started after ${db.pin.failedAttempts} failed attempts. Locked for ${LOCKOUT_MINUTES} minutes.`, {
      failedAttempts: db.pin.failedAttempts,
      lockedUntil: db.pin.lockedUntil,
    });
    writeDb(db);
    return res.status(423).json({
      error: `Too many failed attempts. Dashboard locked for ${LOCKOUT_MINUTES} minutes.`,
      remainingAttempts: 0,
    });
  }

  addAudit(db, 'PIN', 'FAIL', `Incorrect PIN (${db.pin.failedAttempts}/${MAX_FAILED_ATTEMPTS}). ${attemptsLeft} attempt(s) remaining.`, {
    failedAttempts: db.pin.failedAttempts,
    remainingAttempts: attemptsLeft,
  });
  writeDb(db);
  return res.status(401).json({
    error: `Incorrect PIN. ${attemptsLeft} attempt(s) remaining before lockout.`,
    remainingAttempts: attemptsLeft,
  });
});

app.post('/api/reset', (_req, res) => {
  const db = { consents: [], pin: null, auditLog: [] };
  addAudit(db, 'SYSTEM', 'INFO', 'Prototype state reset by user.');
  writeDb(db);
  res.json({ message: 'Prototype state reset.' });
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(srcDir, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Backend simulation running at http://localhost:${PORT}`);
});

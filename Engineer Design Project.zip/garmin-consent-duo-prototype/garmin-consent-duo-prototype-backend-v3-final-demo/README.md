# Garmin Consent Duo Prototype - Backend v3

Educational prototype for a privacy-preserving user consent model and Duo-style PIN access flow for Garmin Venu-series smartwatch data.

## Final Demo Enhancements Added

This version includes the next-step improvements for the final demo:

- Stronger backend validation rules
  - PIN must be exactly 4 digits
  - Weak PINs such as `1111`, `0000`, `1234`, and `2580` are rejected
  - Active consent is required before unlocking the dashboard
  - Consent duration values are validated on the backend

- More customizable consent duration
  - Custom duration amount
  - Duration units: hours, days, or weeks
  - `Until revoked` option
  - Backend calculates and stores `expiresAt`

- More detailed audit logs
  - Event type: CONSENT, PIN, SYSTEM
  - Event status: SUCCESS, FAIL, WARNING, INFO
  - Timestamp and event message
  - Details for attempts, expiration, and lockout

- Enhanced UI feedback
  - Clear success, warning, and error messages
  - Remaining PIN attempts
  - Active consent status shown near PIN status
  - Reset Demo button for repeatable classroom demos

## How to Run

1. Open this folder in Visual Studio Code.
2. Open the terminal.
3. Run:

```bash
npm install
npm start
```

4. Open the browser at:

```text
http://localhost:3000
```

## Recommended Final Demo Flow

1. Click **Reset Demo** to clear old data.
2. Save consent using a custom duration like **2 hours** or **1 week**.
3. Create a secure PIN such as **4826**.
4. Try unlocking with the wrong PIN to show `401 Unauthorized`.
5. Enter the wrong PIN three times to show lockout and `423 Locked`.
6. Show the audit log with structured `[TYPE] [STATUS]` entries.
7. Show the Network tab to prove the frontend is calling backend API endpoints.

## API Endpoints

- `GET /api/health`
- `GET /api/consent/latest`
- `POST /api/consent/save`
- `POST /api/consent/revoke`
- `POST /api/pin/create`
- `POST /api/pin/unlock`
- `GET /api/pin/status`
- `GET /api/audit-log`
- `POST /api/reset`

## Notes

This is a class project simulation. It is not affiliated with Garmin or Cisco Duo and does not connect to real Garmin APIs.

const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const dataPath = path.join(__dirname, 'data.json');
const srcDir = path.join(__dirname, '..', 'src');

app.use(cors());
app.use(express.json());
app.use(express.static(srcDir));

function readDb() {
  try {
    return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
  } catch (error) {
    return { consents: [], pin: null, auditLog: [] };
  }
}

function writeDb(db) {
  fs.writeFileSync(dataPath, JSON.stringify(db, null, 2));
}

function nowStamp() {
  return new Date().toISOString();
}

function addAudit(db, message, level = 'info') {
  db.auditLog.unshift({
    timestamp: nowStamp(),
    level,
    message,
  });
}

function hashPin(pin, salt) {
  return crypto.createHash('sha256').update(`${pin}:${salt}`).digest('hex');
}

function validateConsentPayload(body) {
  if (!body.participant || typeof body.participant !== 'string') {
    return 'Participant name is required.';
  }
  if (!body.device || typeof body.device !== 'string') {
    return 'Device model is required.';
  }
  if (!body.purpose || typeof body.purpose !== 'string') {
    return 'Purpose is required.';
  }
  if (!body.duration || typeof body.duration !== 'string') {
    return 'Consent duration is required.';
  }
  if (!Array.isArray(body.dataTypes) || body.dataTypes.length === 0) {
    return 'Select at least one data type.';
  }
  return null;
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, message: 'Backend simulation is running.' });
});

app.get('/api/consent/latest', (_req, res) => {
  const db = readDb();
  const latest = db.consents[0] || null;
  res.json({ consent: latest });
});

app.post('/api/consent/save', (req, res) => {
  const error = validateConsentPayload(req.body);
  if (error) {
    return res.status(400).json({ error });
  }

  const db = readDb();
  const record = {
    id: crypto.randomUUID(),
    participant: req.body.participant.trim(),
    device: req.body.device,
    purpose: req.body.purpose,
    duration: req.body.duration,
    dataTypes: req.body.dataTypes,
    protections: {
      pseudonymized: Boolean(req.body.protections?.pseudonymized),
      encryptedBeforeSync: Boolean(req.body.protections?.encryptedBeforeSync),
      auditLoggingEnabled: Boolean(req.body.protections?.auditLoggingEnabled),
    },
    consentStatus: 'Active',
    timestamp: nowStamp(),
  };

  db.consents.unshift(record);
  addAudit(db, `Consent saved for ${record.participant}.`);
  writeDb(db);
  return res.status(201).json({ message: 'Consent saved.', consent: record });
});

app.post('/api/consent/revoke', (req, res) => {
  const error = validateConsentPayload(req.body);
  if (error) {
    return res.status(400).json({ error });
  }

  const db = readDb();
  const record = {
    id: crypto.randomUUID(),
    participant: req.body.participant.trim(),
    device: req.body.device,
    purpose: req.body.purpose,
    duration: req.body.duration,
    dataTypes: req.body.dataTypes,
    protections: {
      pseudonymized: Boolean(req.body.protections?.pseudonymized),
      encryptedBeforeSync: Boolean(req.body.protections?.encryptedBeforeSync),
      auditLoggingEnabled: Boolean(req.body.protections?.auditLoggingEnabled),
    },
    consentStatus: 'Revoked',
    timestamp: nowStamp(),
  };

  db.consents.unshift(record);
  addAudit(db, `Consent revoked for ${record.participant}.`, 'warning');
  writeDb(db);
  return res.json({ message: 'Consent revoked.', consent: record });
});

app.get('/api/audit-log', (_req, res) => {
  const db = readDb();
  res.json({ auditLog: db.auditLog });
});

app.post('/api/pin/create', (req, res) => {
  const pin = String(req.body.pin || '').trim();
  const confirmPin = String(req.body.confirmPin || '').trim();

  if (!/^\d{4}$/.test(pin)) {
    return res.status(400).json({ error: 'PIN must be exactly 4 digits.' });
  }
  if (pin !== confirmPin) {
    return res.status(400).json({ error: 'PIN confirmation does not match.' });
  }

  const db = readDb();
  const salt = crypto.randomBytes(16).toString('hex');
  db.pin = {
    salt,
    hash: hashPin(pin, salt),
    createdAt: nowStamp(),
    failedAttempts: 0,
  };
  addAudit(db, 'Local PIN created for dashboard access.');
  writeDb(db);
  return res.status(201).json({ message: 'PIN created successfully.' });
});

app.post('/api/pin/unlock', (req, res) => {
  const enteredPin = String(req.body.pin || '').trim();
  const db = readDb();

  if (!db.pin) {
    addAudit(db, 'Unlock attempt blocked because no PIN exists.', 'warning');
    writeDb(db);
    return res.status(400).json({ error: 'Create a PIN first.' });
  }

  const attemptedHash = hashPin(enteredPin, db.pin.salt);
  if (attemptedHash === db.pin.hash) {
    db.pin.failedAttempts = 0;
    addAudit(db, 'Successful dashboard unlock with PIN/passcode.');
    writeDb(db);
    return res.json({ message: 'Access granted. Privacy dashboard unlocked.' });
  }

  db.pin.failedAttempts += 1;
  addAudit(db, `Failed dashboard unlock attempt (${db.pin.failedAttempts} failed attempts).`, 'warning');
  writeDb(db);
  return res.status(401).json({ error: 'Incorrect PIN. Access denied.' });
});

app.post('/api/reset', (_req, res) => {
  const db = { consents: [], pin: null, auditLog: [] };
  addAudit(db, 'Prototype state reset by user.');
  writeDb(db);
  res.json({ message: 'Prototype state reset.' });
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(srcDir, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Backend simulation running at http://localhost:${PORT}`);
});
